TDEE: 2653 kcal (rounded)

Macronutrient Breakdown for Weight Loss (40/30/30 ratio):

Protein: 265 g
Carbohydrates: 199 g
Fat: 88 g

Note: These are estimates.  Individual needs may vary. Consult with a registered dietitian or healthcare professional for personalized advice.