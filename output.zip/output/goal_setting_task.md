```tool_code
Thought: I need to gather information from the user to understand their fitness goals.  I'll start by asking clarifying questions.  Since I don't have access to the user's input directly, I cannot use any tools yet.
```
