**Daily Meal Plan (Approximately 2653 kcal, 265g Protein, 199g Carbohydrates, 88g Fat – Adjust portion sizes as needed):**

**Breakfast (approx. 500 kcal, 50g Protein, 30g Carbs, 20g Fat):**

*   Oatmeal (1 cup dry) with 1 scoop whey protein powder (30g protein), 1/4 cup berries, and 1 tablespoon of chia seeds.

**Mid-Morning Snack (approx. 250 kcal, 25g Protein, 15g Carbs, 10g Fat):**

*   Greek yogurt (1 cup) with 1/4 cup almonds and a small apple.

**Lunch (approx. 700 kcal, 70g Protein, 50g Carbs, 30g Fat):**

*   Grilled chicken salad (6oz grilled chicken breast, 2 cups mixed greens, 1/2 avocado, 1/4 cup olive oil and vinegar dressing).

**Afternoon Snack (approx. 200 kcal, 20g Protein, 10g Carbs, 10g Fat):**

*   Protein shake (whey or casein) with a handful of almonds.

**Dinner (approx. 800 kcal, 80g Protein, 70g Carbs, 20g Fat):**

*   Salmon (4oz) with 1 cup quinoa and 1 cup steamed broccoli.

**Evening Snack (Optional, approx. 200 kcal, 20g Protein, 14g Carbs, 8g Fat):**

*   Casein protein shake before bed.


**Weekly Meal Plan (Example -  Rotate proteins and vegetables for variety):**


**Monday:**

*   Breakfast: Oatmeal with protein powder, berries, chia seeds.
*   Mid-morning Snack: Greek yogurt with almonds and apple.
*   Lunch: Chicken salad (as above).
*   Afternoon Snack: Protein shake with almonds.
*   Dinner: Salmon with quinoa and broccoli.
*   Evening Snack: Casein protein shake.

**Tuesday:**

*   Breakfast: Scrambled eggs (3) with spinach and whole-wheat toast.
*   Mid-morning Snack: Cottage cheese (1 cup) with berries.
*   Lunch: Leftover salmon and quinoa.
*   Afternoon Snack: Hard-boiled eggs (2).
*   Dinner: Lean ground beef stir-fry with brown rice and mixed vegetables.
*   Evening Snack: Casein protein shake.


**Wednesday:**

*   Breakfast: Protein pancakes (made with protein powder) with fruit.
*   Mid-morning Snack: Protein bar (check macros).
*   Lunch: Turkey breast sandwich on whole-wheat bread with lettuce and tomato.
*   Afternoon Snack: Greek yogurt with fruit.
*   Dinner: Chicken breast with sweet potato and green beans.
*   Evening Snack: Casein protein shake.


**Thursday:**

*   Breakfast: Oatmeal with protein powder, berries, chia seeds.
*   Mid-morning Snack:  Peanut butter (2 tablespoons) on whole-wheat toast.
*   Lunch: Leftover chicken breast with sweet potato and green beans.
*   Afternoon Snack:  Almonds and a small orange.
*   Dinner:  Lentil soup with a side salad.
*   Evening Snack:  Casein protein shake.


**Friday:**

*   Breakfast: Scrambled eggs (3) with whole-wheat toast and avocado.
*   Mid-morning Snack:  Greek yogurt with fruit.
*   Lunch: Tuna salad sandwich on whole-wheat bread.
*   Afternoon Snack: Protein shake.
*   Dinner:  Baked chicken breast with roasted vegetables (broccoli, carrots, peppers).
*   Evening Snack: Casein protein shake.


**Saturday & Sunday:**  Allow for flexibility and social meals.  Focus on making healthy choices and tracking your macros as best as possible.


**Important Notes:**

*   This is a sample plan. Adjust portion sizes based on your individual needs and activity level.
*   Prioritize whole, unprocessed foods.
*   Drink plenty of water throughout the day.
*   Consult with a registered dietitian or healthcare professional for personalized advice.
*   This plan assumes a moderate activity level.  Adjust calories and macros if you have a higher or lower activity level.  Consider adding additional snacks or increasing portion sizes on high-intensity training days.
*   Pay attention to how your body feels and adjust the plan accordingly.


This meal plan provides a framework.  The success of any diet plan hinges on consistency and listening to your body's cues.  Remember to stay hydrated and consult professionals for personalized guidance.