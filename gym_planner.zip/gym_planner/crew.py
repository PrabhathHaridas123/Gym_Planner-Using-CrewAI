from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import SerperDevTool
from dotenv import load_dotenv

load_dotenv()


@CrewBase
class GymPlanner:
    """GymPlanner crew"""

    agents_config = "config/agents.yaml"
    tasks_config = "config/tasks.yaml"

    @agent
    def goal_setting_agent(self) -> Agent:
        return Agent(
            config=self.agents_config["goal_setting_agent"],
            verbose=True,
            tools=[SerperDevTool()],
        )

    @agent
    def macro_calculator_agent(self) -> Agent:
        return Agent(
            config=self.agents_config["macro_calculator_agent"],
            verbose=True,
            tools=[SerperDevTool()],
        )

    @agent
    def diet_planner_agent(self) -> Agent:
        return Agent(
            config=self.agents_config["diet_planner_agent"],
            verbose=True,
            tools=[SerperDevTool()],
        )

    @agent
    def workout_schedule_agent(self) -> Agent:
        return Agent(
            config=self.agents_config["workout_schedule_agent"],
            verbose=True,
            tools=[SerperDevTool()],
        )

    @agent
    def training_plan_agent(self) -> Agent:
        return Agent(
            config=self.agents_config["training_plan_agent"],
            verbose=True,
            tools=[SerperDevTool()],
        )

    @agent
    def supplement_recommendation_agent(self) -> Agent:
        return Agent(
            config=self.agents_config["supplement_recommendation_agent"],
            verbose=True,
            tools=[SerperDevTool()],
        )

    @agent
    def progress_tracking_agent(self) -> Agent:
        return Agent(
            config=self.agents_config["progress_tracking_agent"],
            verbose=True,
            tools=[SerperDevTool()],
        )

    @agent
    def lifestyle_optimizer_agent(self) -> Agent:
        return Agent(
            config=self.agents_config["lifestyle_optimizer_agent"],
            verbose=True,
            tools=[SerperDevTool()],
        )

    @agent
    def browser_agent(self) -> Agent:
        return Agent(
            config=self.agents_config["browser_agent"],
            verbose=True,
        )

    @task
    def goal_setting_task(self) -> Task:
        return Task(
            config=self.tasks_config["goal_setting_task"],
            output_file="output/goal_setting_task.md",
        )

    @task
    def macro_calculator_task(self) -> Task:
        return Task(
            config=self.tasks_config["macro_calculator_task"],
            output_file="output/macro_calculator_task.md",
        )

    @task
    def diet_planner_task(self) -> Task:
        return Task(
            config=self.tasks_config["diet_planner_task"],
            output_file="output/diet_planner_task.md",
        )

    @task
    def workout_schedule_task(self) -> Task:
        return Task(
            config=self.tasks_config["workout_schedule_task"],
            output_file="output/workout_schedule_task.md",
        )

    @task
    def training_plan_task(self) -> Task:
        return Task(
            config=self.tasks_config["training_plan_task"],
            output_file="output/training_plan_task.md",
        )

    @task
    def supplement_recommendation_task(self) -> Task:
        return Task(
            config=self.tasks_config["supplement_recommendation_task"],
            output_file="output/supplements.txt",
        )

    @task
    def progress_tracking_task(self) -> Task:
        return Task(
            config=self.tasks_config["progress_tracking_task"],
            output_file="output/progress_tracking_task.md",
        )

    @task
    def lifestyle_optimizer_task(self) -> Task:
        return Task(
            config=self.tasks_config["lifestyle_optimizer_task"],
            output_file="output/lifestyle_optimizer_task.md",
        )

    @task
    def browser_task(self) -> Task:
        return Task(
            config=self.tasks_config["browser_task"],
            output_file="output/output.txt",
        )

    @crew
    def crew(self) -> Crew:
        return Crew(
            agents=self.agents,
            tasks=self.tasks,
            process=Process.sequential,
            verbose=True,
        )
